import archer from './archer.png';
import barbarian from './barbarian.png';
import bard from './bard.png';
import gunner from './gunner.png';
import healer from './healer.png';
import inventor from './inventor.png';
import lancer from './lancer.png';
import monk from './monk.png';
import necromancer from './necromancer.png';
import summoner from './summoner.png';
import warrior from './warrior.png';
import wizard from './wizard.png';


export {archer, barbarian, bard, gunner, healer, inventor, lancer, monk, necromancer, summoner, warrior, wizard}