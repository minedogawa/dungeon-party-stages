// import partyImages from './partyImages'

// export const partyData = [{
//     "class": "archer",
//     "attack": 8,
//     "defense": 4,
//     "agility": 9,
//     "accuracy": 10,
//     "utility": 7,
//     'image': partyImages.archer
//   },
//   {
//     "class": "barbarian",
//     "attack": 10,
//     "defense": 6,
//     "agility": 6,
//     "accuracy": 7,
//     "utility": 5,
//     'image': partyImages.barbarian
//   },
//   {
//     "class": "bard",
//     "attack": 5,
//     "defense": 5,
//     "agility": 7,
//     "accuracy": 8,
//     "utility": 8,
//     'image': partyImages.bard
//   },
//   {
//     "class": "gunner",
//     "attack": 9,
//     "defense": 5,
//     "agility": 7,
//     "accuracy": 9,
//     "utility": 6,
//     'image': partyImages.gunner
//   },
//   {
//     "class": "healer",
//     "attack": 3,
//     "defense": 7,
//     "agility": 6,
//     "accuracy": 8,
//     "utility": 9,
//     'image': partyImages.healer
//   },
//   {
//     "class": "inventor",
//     "attack": 6,
//     "defense": 6,
//     "agility": 7,
//     "accuracy": 7,
//     "utility": 7,
//     'image': partyImages.inventor
//   },
//   {
//     "class": "lancer",
//     "attack": 9,
//     "defense": 8,
//     "agility": 6,
//     "accuracy": 7,
//     "utility": 6,
//     'image': partyImages.lancer
//   },
//   {
//     "class": "monk",
//     "attack": 7,
//     "defense": 8,
//     "agility": 9,
//     "accuracy": 8,
//     "utility": 7,
//     'image': partyImages.monk
//   },
//   {
//     "class": "necromancer",
//     "attack": 8,
//     "defense": 4,
//     "agility": 6,
//     "accuracy": 8,
//     "utility": 8,
//     'image': partyImages.necromancer
//   },
//   {
//     "class": "summoner",
//     "attack": 7,
//     "defense": 6,
//     "agility": 7,
//     "accuracy": 7,
//     "utility": 7,
//     'image': partyImages.summoner
//   },
//   {
//     "class": "warrior",
//     "attack": 9,
//     "defense": 9,
//     "agility": 5,
//     "accuracy": 6,
//     "utility": 6,
//     'image': partyImages.warrior
//   },
//   {
//     "class": "wizard",
//     "attack": 10,
//     "defense": 5,
//     "agility": 6,
//     "accuracy": 9,
//     "utility": 8,
//     'image': partyImages.wizard
//   }
// ]