// import archerImage from "../assets/images/party/archer.png";
// import barbarianImage from "../assets/images/party/barbarian.png";
// import bardImage from "../assets/images/party/bard.png";
// import gunnerImage from "../assets/images/party/gunner.png";
// import healerImage from "../assets/images/party/healer.png";
// import inventorImage from "../assets/images/party/inventor.png";
// import lancerImage from "../assets/images/party/lancer.png";
// import monkImage from "../assets/images/party/monk.png";
// import necromancerImage from "../assets/images/party/necromancer.png";
// import summonerImage from "../assets/images/party/summoner.png";
// import warriorImage from "../assets/images/party/warrior.png";
// import wizardImage from "../assets/images/party/wizard.png";

// export const partyImages = {
//     "archer": archerImage,
//     "barbarian": barbarianImage,
//     "bard": bardImage,
//     "gunner": gunnerImage,
//     "healer": healerImage,
//     "inventor": inventorImage,
//     "lancer": lancerImage,
//     "monk": monkImage,
//     "necromancer": necromancerImage,
//     "summoner": summonerImage,
//     "warrior": warriorImage,
//     "wizard": wizardImage
// };